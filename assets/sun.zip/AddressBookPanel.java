/********************************************************************
 * Copyright (c) 1998-99 The Bean Factory, LLC. 
 * All Rights Reserved.
 *
 * The Bean Factory, LLC. makes no representations or 
 * warranties about the suitability of the software, either express
 * or implied, including but not limited to the implied warranties of 
 * merchantableness, fitness for a particular purpose, or 
 * non-infringement. The Bean Factory, LLC. shall not be 
 * liable for any damages suffered by licensee as a result of using,
 * modifying or distributing this software or its derivatives.
 *
 *******************************************************************/


import java.awt.*;                  //AWT classes
import java.awt.event.*;            //AWT event classes
import javax.swing.*;               //Swing classes
import javax.swing.event.*;         //Swing events
import javax.swing.table.*;         //JTable models


 /********************************************************************
  <B>AddresBookPanel</B> create a custome table model object and add
  it to JTable.
 
  @version      : 1.0
  @author       : Sun Koh
 
  @see  AddressBookModel 
 ********************************************************************/
 
 
 public class AddressBookPanel
 extends JPanel {
 
 //
 // METHODS
 //
    /**
     Constructor - create JTable and a custome table model
     */
    public AddressBookPanel(){
        
        //creatae JTable
        JTable table = new JTable();
        //create Model
        AddressBookModel model = new AddressBookModel();
        
        table.setModel(model);
        
        setLayout(new BorderLayout());
        add( new JScrollPane( table ), BorderLayout.CENTER);

    }   //end method
    
 
    /**
     Return preferrred size of this panel
     
     @return    a dimension of the panel
     */
    public Dimension getPreferredSize(){
        return new Dimension(600, 300);
    }
    /**
     Return minimun size of this panel
     
     @return    a dimension of the panel
     */
    public Dimension getMinimunSize(){
        return new Dimension(200, 200);
    } 
 
 }//end of AddressBookPanel class

