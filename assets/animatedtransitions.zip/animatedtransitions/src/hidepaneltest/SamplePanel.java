/*
 * Created by JFormDesigner on Mon Sep 24 08:33:20 EDT 2007
 */

package hidepaneltest;

import info.clearthought.layout.TableLayout;
import info.clearthought.layout.TableLayoutConstraints;
import org.jdesktop.animation.timing.Animator;
import org.jdesktop.animation.timing.interpolation.SplineInterpolator;
import org.jdesktop.animation.transitions.ScreenTransition;
import org.jdesktop.animation.transitions.TransitionTarget;
import org.jdesktop.swingx.JXButton;
import org.jdesktop.swingx.JXLabel;
import org.jdesktop.swingx.JXPanel;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * This test is to determine if animatedtransitions api can be used to
 * hide a panel out of sight and then show it again. This is used in the
 * container in shell... right now, it's a hack using a JSplitPane and
 * an animation to hide it.
 * <p/>
 *
 * @author Nazmul Idris
 *         Date: Sep 24, 2007
 *         Time: 8:16:23 AM
 */
public class SamplePanel extends SwingMain implements TransitionTarget {

    public SamplePanel() {
        initComponents();

        // -- create the animator object (set delay and interpolator)
        Animator anim = new Animator(200);
        // http://javadesktop.org/swinglabs/demos/timingframework/SplineEditor.jnlp
        anim.setInterpolator(new SplineInterpolator(
                0.97f, 0.03f,
                1.0f, 0.00f));

        // -- setup the screen transition object, with TransitionTarget & Animator
        st = new ScreenTransition(
                tablePanel,
                this,
                anim
        );

    }

    // -- reference to ScreenTransition used...
    ScreenTransition st;

    // -- keep track of what is currently hidden or shown...
    boolean leftPanelIsHidden = false;

    public void setupNextScreen() {

        // -- show left column
        if (leftPanelIsHidden) {
            tablePanel.removeAll();
            tablePanel.add(
                    leftLabel,
                    new TableLayoutConstraints(0, 0, 0, 0, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));
            tablePanel.add(
                    rightLabel,
                    new TableLayoutConstraints(1, 0, 1, 0, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));

            tablePanel.revalidate();
            tablePanel.repaint();
            leftPanelIsHidden = false;
        }
        // -- hide left column
        else {
            tablePanel.removeAll();
            tablePanel.add(
                    rightLabel,
                    new TableLayoutConstraints(0, 0, 1, 0, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL)
            );

            tablePanel.revalidate();
            tablePanel.repaint();
            leftPanelIsHidden = true;
        }

    }

    public JXPanel getBorderPanel() {
        return borderPanel;
    }

    private void toggleAction() {
        st.start();
    }

    private void initComponents() {
        // JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
        // Generated using JFormDesigner non-commercial license
        borderPanel = new JXPanel();
        tablePanel = new JXPanel();
        leftLabel = new JXLabel();
        rightLabel = new JXLabel();
        buttonPanel = new JXPanel();
        xButton1 = new JXButton();

        //======== borderPanel ========
        {
            borderPanel.setLayout(new BorderLayout(5, 5));

            //======== tablePanel ========
            {
                tablePanel.setLayout(new TableLayout(new double[][]{
                        {0.3, 0.7},
                        {TableLayout.FILL}}));
                ((TableLayout) tablePanel.getLayout()).setHGap(5);
                ((TableLayout) tablePanel.getLayout()).setVGap(5);

                //---- leftLabel ----
                leftLabel.setText("Left Panel (30%)");
                tablePanel.add(leftLabel, new TableLayoutConstraints(0, 0, 0, 0, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));

                //---- rightLabel ----
                rightLabel.setText("Right Panel (Grow)");
                tablePanel.add(rightLabel, new TableLayoutConstraints(1, 0, 1, 0, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));
            }
            borderPanel.add(tablePanel, BorderLayout.CENTER);

            //======== buttonPanel ========
            {
                buttonPanel.setLayout(new GridLayout(1, 2, 5, 5));

                //---- xButton1 ----
                xButton1.setText("toggle");
                xButton1.addActionListener(new ActionListener() {
                    public void actionPerformed(ActionEvent e) {
                        toggleAction();
                    }
                });
                buttonPanel.add(xButton1);
            }
            borderPanel.add(buttonPanel, BorderLayout.SOUTH);
        }
        // JFormDesigner - End of component initialization  //GEN-END:initComponents
    }

    // JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
    // Generated using JFormDesigner non-commercial license
    private JXPanel borderPanel;
    private JXPanel tablePanel;
    private JXLabel leftLabel;
    private JXLabel rightLabel;
    private JXPanel buttonPanel;
    private JXButton xButton1;
    // JFormDesigner - End of variables declaration  //GEN-END:variables
}
