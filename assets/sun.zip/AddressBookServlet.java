/********************************************************************
 * Copyright (c) 1998-99 The Bean Factory, LLC. 
 * All Rights Reserved.
 *
 * The Bean Factory, LLC. makes no representations or 
 * warranties about the suitability of the software, either express
 * or implied, including but not limited to the implied warranties of 
 * merchantableness, fitness for a particular purpose, or 
 * non-infringement. The Bean Factory, LLC. shall not be 
 * liable for any damages suffered by licensee as a result of using,
 * modifying or distributing this software or its derivatives.
 *
 *******************************************************************/

import com.sun.xml.tree.*;
import org.xml.sax.*;
import org.w3c.dom.*;

import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;

/********************************************************************
 <B>AddressBookServlet</B> displays an XML document in an HTML table 
 format. The servlet creates a Document from an XML document and 
 renders the information in it to HTML after parsing it.

 @version      : 1.0
 @author       : Nazmul Idris

********************************************************************/

public class AddressBookServlet extends HttpServlet {
    //CONSTANTS
    public static final String 
        URL = "http://beanfactory.com/xml/AddressBook.xml";
    public static final String ROOT_ELEMENT_TAG = "PERSON";
    
    public static final String[] colNames ={
        "LASTNAME",
        "FIRSTNAME",
        "COMPANY",
        "EMAIL"
    };


    //DATA
    protected Document doc;

    /**
     When this method receives a request from a browser, it returns a
     XML document in table format.
     
     @param     req     http servlet request
     @param     res     http servlet response
     @exception ServletException
     @exception IOException
     */
    protected void doGet(HttpServletRequest req, HttpServletResponse res)
    throws ServletException, IOException {

        res.setContentType("text/html");

        PrintWriter out = new PrintWriter(res.getOutputStream());

        out.print("<html>");
        out.print("<title>XML and Java2 Tutorial Part 1: Sun Parser</title>");
        out.print( "<center>" );
        out.print( "<head><pre>http://beanfactory.com/xml/AddressBook.xml</pre></head><hr>" );

        //format a table
        out.print( "<table BORDER=0 CELLSPACING=2 CELLPADDING=10 BGCOLOR=\"#CFCFFF\" >" );

        out.print( "<tr>");
        //display table column
        for(int i=0; i<colNames.length; i++){
            out.print( "<td><b><center>"+colNames[i]+"</center></b></td>" );
        }
        out.print( "</tr>" );

        //need to iterate the doc to get the fields in it
        int rowCount = XmlUtils.getSize( doc , ROOT_ELEMENT_TAG );

        for(int r=0; r<rowCount; r++) {
            out.print( "<tr>" );

            Element row = XmlUtils.getElement( doc , ROOT_ELEMENT_TAG , r );
            
            int colCount = colNames.length;
            
            for(int c=0; c < colCount; c++) {
                out.print( "<td>" );
                out.print( XmlUtils.getValue( row , colNames[c] ) );
                out.print( "</td>" );
            }

            out.print( "</tr>" );

        }//endfor
        
        out.print( "</table>" );
        out.print( "<hr>Copyright The Bean Factory, LLC. 1998-1999. All Rights Reserved.");
        out.print( "</center>" );

        out.println("</body>");
        out.println("</html>");

        out.flush();
        out.close();

    }//end method

    /**
     Create a DOM from an XML document when the servlet starts up.
     
     @param     config  servlet configuration
     @exception ServletException
     */
    public void init( ServletConfig config ) throws ServletException{
        super.init( config );

        //load the Document
        try{
            //create xml document
            doc = XmlDocumentBuilder.createXmlDocument(URL);
        }
        catch( Exception e ) {
            System.out.println( e );
        }


    }

    /**
     Return servlet information
     
     @return    message about this servlet
     */
    public String getServletInfo(){
        return "Copyright The Bean Factory, LLC. 1998. All Rights Reserved.";
    }

}//end class
