/*
 * Created by JFormDesigner on Mon Mar 31 18:39:40 EDT 2008
 */

package Samples.Part4;

import Samples.SharedComponents.*;
import info.clearthought.layout.*;

import javax.swing.*;

/**
 * @author nazmul idris
 */
public class WeatherDisplay extends GradientPanel {
	public WeatherDisplay() {
		initComponents();
	}

  public JLabel getWeatherLabel(){
    return lblWeatherImage;
  }

  public JLabel getFeelsLikeTTF(){
    return lblFeelsLikeTemp;
  }

  public JLabel getCurrentTempTTF(){
    return lblCurrentTemp;
  }

  private void initComponents() {
		// JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
		// Generated using JFormDesigner non-commercial license
		label1 = new JLabel();
		lblFeelsLikeTemp = new JLabel();
		label2 = new JLabel();
		lblCurrentTemp = new JLabel();
		lblWeatherImage = new JLabel();

		//======== this ========
		setLayout(new TableLayout(new double[][] {
			{TableLayout.PREFERRED, TableLayout.PREFERRED, TableLayout.PREFERRED, TableLayout.FILL, TableLayout.PREFERRED},
			{TableLayout.PREFERRED, TableLayout.PREFERRED, TableLayout.PREFERRED, TableLayout.PREFERRED, TableLayout.FILL}}));
		((TableLayout)getLayout()).setHGap(5);
		((TableLayout)getLayout()).setVGap(5);

		//---- label1 ----
		label1.setText("Feels like temperature:");
		add(label1, new TableLayoutConstraints(1, 1, 1, 1, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));

		//---- lblFeelsLikeTemp ----
		lblFeelsLikeTemp.setOpaque(false);
		add(lblFeelsLikeTemp, new TableLayoutConstraints(2, 1, 3, 1, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));

		//---- label2 ----
		label2.setText("Current temperature:");
		add(label2, new TableLayoutConstraints(1, 2, 1, 2, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));

		//---- lblCurrentTemp ----
		lblCurrentTemp.setOpaque(false);
		add(lblCurrentTemp, new TableLayoutConstraints(2, 2, 3, 2, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));

		//---- lblWeatherImage ----
		lblWeatherImage.setHorizontalAlignment(SwingConstants.CENTER);
		lblWeatherImage.setHorizontalTextPosition(SwingConstants.CENTER);
		add(lblWeatherImage, new TableLayoutConstraints(1, 3, 3, 3, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));
		// JFormDesigner - End of component initialization  //GEN-END:initComponents
	}

	// JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
	// Generated using JFormDesigner non-commercial license
	private JLabel label1;
	private JLabel lblFeelsLikeTemp;
	private JLabel label2;
	private JLabel lblCurrentTemp;
	private JLabel lblWeatherImage;
	// JFormDesigner - End of variables declaration  //GEN-END:variables
}
