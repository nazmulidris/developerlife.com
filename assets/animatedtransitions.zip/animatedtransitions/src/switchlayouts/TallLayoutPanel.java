/*
 * Created by JFormDesigner on Mon Sep 24 13:02:00 EDT 2007
 */

package switchlayouts;

import info.clearthought.layout.TableLayout;
import info.clearthought.layout.TableLayoutConstraints;
import org.jdesktop.swingx.JXLabel;
import org.jdesktop.swingx.JXPanel;

/**
 * @author nazmul idris
 */
public class TallLayoutPanel extends JXPanel {
    public TallLayoutPanel() {
        initComponents();
    }

    private void initComponents() {
        // JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
        // Generated using JFormDesigner non-commercial license
        xLabel1 = new JXLabel();
        xLabel2 = new JXLabel();
        xLabel3 = new JXLabel();

        //======== this ========
        setLayout(new TableLayout(new double[][]{
                {0.3, TableLayout.FILL},
                {0.5, 0.5}}));
        ((TableLayout) getLayout()).setHGap(5);
        ((TableLayout) getLayout()).setVGap(5);

        //---- xLabel1 ----
        xLabel1.setText("Left");
        add(xLabel1, new TableLayoutConstraints(0, 0, 0, 1, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));

        //---- xLabel2 ----
        xLabel2.setText("Middle");
        add(xLabel2, new TableLayoutConstraints(1, 0, 1, 0, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));

        //---- xLabel3 ----
        xLabel3.setText("Right");
        add(xLabel3, new TableLayoutConstraints(1, 1, 1, 1, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));
        // JFormDesigner - End of component initialization  //GEN-END:initComponents
    }

    // JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
    // Generated using JFormDesigner non-commercial license
    private JXLabel xLabel1;
    private JXLabel xLabel2;
    private JXLabel xLabel3;
    // JFormDesigner - End of variables declaration  //GEN-END:variables
}
