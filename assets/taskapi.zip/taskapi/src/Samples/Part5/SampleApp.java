/*
 * Created by JFormDesigner on Thu Mar 27 12:38:02 EDT 2008
 */

package Samples.Part5;

import Samples.SharedComponents.*;
import Task.*;
import Task.Manager.*;
import Task.ProgressMonitor.*;
import Task.Support.CoreSupport.*;
import Task.Support.EnhancedListeners.*;
import Task.Support.GUISupport.*;
import com.jgoodies.forms.factories.*;
import info.clearthought.layout.*;
import org.apache.commons.httpclient.*;
import org.apache.commons.httpclient.methods.*;
import org.jdesktop.animation.timing.*;
import org.jdesktop.animation.timing.interpolation.*;
import org.jdesktop.animation.transitions.*;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.event.*;
import java.awt.*;
import java.awt.event.*;
import java.beans.*;
import java.util.*;
import java.util.List;
import java.util.concurrent.*;

/** @author nazmul idris */
public class SampleApp extends JFrame {
//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
// data members
//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
/** reference to taskmanager */
private TaskManager _taskManager = new TaskManager();
private HashMap<AbstractTask, TaskDetail> _taskDetailHashMap = new HashMap<AbstractTask, TaskDetail>();

//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
// main method...
//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

public static void main(String[] args) {
  Utils.createInEDT(SampleApp.class);
}

//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
// constructor
//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

private void doInit() {
  GUIUtils.setAppIcon(this, "burn.png");
  GUIUtils.centerOnScreen(this);
  setVisible(true);

  int W = 28, H = W;
  boolean blur = false;
  float alpha = .7f;

  try {
    btnStartTask1.setIcon(ImageUtils.loadScaledBufferedIcon("ok1.png", W, H, blur, alpha));
    btnShutdownManager.setIcon(ImageUtils.loadScaledBufferedIcon("exit.png", W, H, blur, alpha));
    btnClearStatus.setIcon(ImageUtils.loadScaledBufferedIcon("bulb.png", W, H, blur, alpha));
    btnQuit.setIcon(ImageUtils.loadScaledBufferedIcon("charging.png", W, H, blur, alpha));
    label1.setIcon(ImageUtils.loadScaledBufferedIcon("alert-stop.png", W, H, blur, alpha));
  }
  catch (Exception e) {
    System.out.println(e);
  }

  listAutoShutdownSignals.setListData(AutoShutdownSignals.values());

  _setupTaskManager();
}

//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
// setup the TaskManager listener
//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

private void _setupTaskManager() {

  Animator anim = new Animator(1000);
  anim.setInterpolator(new SplineInterpolator(
      0.97f, 0.03f,
      1.0f, 0.00f));

  final List<AbstractTask> tasks = new Vector<AbstractTask>();
  final BitRegister removeFlag = new BitRegister(true);
  final ScreenTransition st = new ScreenTransition(taskPanel,
                                                   new TransitionTarget() {
                                                     public void setupNextScreen() {

                                                       for (AbstractTask task : tasks) {
                                                         if (removeFlag.isSet())
                                                           taskPanel.remove(_taskDetailHashMap.get(task));
                                                         else
                                                           taskPanel.add(_taskDetailHashMap.get(task));
                                                       }

                                                       tasks.clear();

                                                     }//end setupNextScreen
                                                   },
                                                   anim);

  _taskManager.addListener(new TaskListChangeListener(true, EnhancedListener.EDTPolicy.RunInEDT) {
    public void taskListChanged(TaskListChangeEvent evt) {
      AbstractTask task = evt.getTask();
      switch (evt.getType()) {
        case Register:
          register(task);
          break;
        case Shutdown:
          shutdown(task);
          break;
        case Unregister:
          unregister(task);
          break;
      }
    }
    private void unregister(AbstractTask task) {
      TaskDetail details = _taskDetailHashMap.get(task);
      if (details == null) return;
      tasks.add(task);
      removeFlag.set();
      st.start();
    }
    private void shutdown(AbstractTask task) {
      TaskDetail details = _taskDetailHashMap.get(task);
      if (details == null) return;
      details.ttfStatus.setText("TASK HAS BEEN SHUTDOWN");
    }
    private void register(AbstractTask task) {
      final TaskDetail details = new TaskDetail();

      details.ttfName.setText(task.getName());
      details.ttfDescription.setText(task.getDescription());

      PropertyChangeListener progressListener = new PropertyChangeListener() {
        public void propertyChange(PropertyChangeEvent evt) {
          details.ttfProgressMessage.setText(ProgressMonitorUtils.parseMessageFrom(evt));
          details.progressBar.setValue(ProgressMonitorUtils.parsePercentFrom(evt));
        }
      };
      task.getUIHook().enableRecieveStatusNotification(true);
      task.getUIHook().enableSendStatusNotification(true);
      task.getUIHook().addRecieveStatusListener(progressListener);
      task.getUIHook().addSendStatusListener(progressListener);

      task.addStatusListener(new PropertyChangeListener() {
        public void propertyChange(PropertyChangeEvent evt) {
          details.ttfStatus.setText(
              ProgressMonitorUtils.parseStatusMessageFrom(evt));
        }
      });

      _taskDetailHashMap.put(task, details);
      tasks.add(task);
      removeFlag.clear();
      st.start();
    }
  });
}

/** simply dump status info to the textarea */
private void sout(final String s) {
  Runnable soutRunner = new Runnable() {
    public void run() {
      if (ttaStatus.getText().equals("")) {
        ttaStatus.setText(s);
      }
      else {
        ttaStatus.setText(ttaStatus.getText() + "\n" + s);
      }
    }
  };

  if (ThreadUtils.isInEDT()) {
    soutRunner.run();
  }
  else {
    SwingUtilities.invokeLater(soutRunner);
  }
}

//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
// wire the UI up to actions
//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

private void autoShutdownListChanged(ListSelectionEvent e) {
  if (e.getValueIsAdjusting() || listAutoShutdownSignals.isSelectionEmpty()) return;
  AutoShutdownSignals signal = AutoShutdownSignals.valueOf(
      listAutoShutdownSignals.getSelectedValue().toString()
  );

  _taskManager.autoShutdownOn(signal);

  sout("Fire TaskManager.autoShutdownOn("+signal.toString()+")");
  listAutoShutdownSignals.clearSelection();
  label1.requestFocus();
}

@SuppressWarnings({"unchecked"})
private void startTask1Action() {
  final String name = "Recurring HTTP GET Task";
  RecurringNetworkTask<ByteBuffer> task = new RecurringNetworkTask(
      _taskManager,
      new TaskExecutorAdapter<ByteBuffer>() {
        @Override public String getName() {
          return name;
        }
        public ByteBuffer doInBackground(Future<ByteBuffer> swingWorker, SwingUIHookAdapter hook) throws Exception {
          GetMethod get =
              new GetMethod(
                  "http://seriouswheels.com/pics-2008/def/2008-Fireblade-Concept-Design-by-Idries-Noah-Rear-And-Side-1920x1440.jpg");
          new HttpClient().executeMethod(get);

          return HttpUtils.getMonitoredResponse(hook, get);
        }
      },
      name,
      "Recurring Network Task, AppShutdown",
      AutoShutdownSignals.AppShutdown
  );

  try {
    task.start(5);
  }
  catch (TaskException e) {
    sout(e.getMessage());
  }
}

private void shutdownAllAction() {
  sout("Removing all the \"soft\" TaskListChangeListeners registered with TaskManager. The UI will no longer be" +
       "connected to the TaskManager! When you start tasks or stop them, you won't see any feedback in the UI.");
  _taskManager.shutdownAll();
}

private void cboxIsOnlineItemStateChanged() {
  if (cboxIsOnline.isSelected()) {
    _taskManager.online();
  }
  else {
    _taskManager.offline();
  }
}

private void quitProgram() {
  _taskManager.shutdownAll();
  System.exit(0);
}

private void clearSystemOut() {
  ttaStatus.setText(null);
}

//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
// JFormDesigner generated stuff...
//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

public SampleApp() {
  initComponents();
  doInit();
}

private void initComponents() {
  // JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
  // Generated using JFormDesigner non-commercial license
  dialogPane = new GradientPanel();
  contentPanel = new JPanel();
  panel1 = new JPanel();
  btnStartTask1 = new JButton();
  label1 = new JLabel();
  btnClearStatus = new JButton();
  btnShutdownManager = new JButton();
  listAutoShutdownSignals = new JList();
  btnQuit = new JButton();
  cboxIsOnline = new JCheckBox();
  taskPanel = new GradientPanel();
  scrollPane1 = new JScrollPane();
  ttaStatus = new JTextArea();

  //======== this ========
  setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
  setTitle("Part 5 - TaskManager - monitoring and stopping tasks.");
  setIconImage(null);
  Container contentPane = getContentPane();
  contentPane.setLayout(new BorderLayout());

  //======== dialogPane ========
  {
  	dialogPane.setBorder(new EmptyBorder(12, 12, 12, 12));
  	dialogPane.setOpaque(false);
  	dialogPane.setLayout(new BorderLayout());

  	//======== contentPanel ========
  	{
  		contentPanel.setOpaque(false);
  		contentPanel.setLayout(new TableLayout(new double[][] {
  			{TableLayout.FILL},
  			{TableLayout.PREFERRED, TableLayout.FILL, TableLayout.PREFERRED}}));
  		((TableLayout)contentPanel.getLayout()).setHGap(5);
  		((TableLayout)contentPanel.getLayout()).setVGap(5);

  		//======== panel1 ========
  		{
  			panel1.setOpaque(false);
  			panel1.setBorder(new CompoundBorder(
  				new TitledBorder("Task Control - start Tasks, and use TaskManager to autostop and shutdown"),
  				Borders.DLU2_BORDER));
  			panel1.setLayout(new TableLayout(new double[][] {
  				{0.24, TableLayout.FILL, TableLayout.FILL, 0.17, TableLayout.FILL, 0.2},
  				{TableLayout.PREFERRED, TableLayout.PREFERRED, TableLayout.PREFERRED}}));
  			((TableLayout)panel1.getLayout()).setHGap(5);
  			((TableLayout)panel1.getLayout()).setVGap(5);

  			//---- btnStartTask1 ----
  			btnStartTask1.setText("Start Task");
  			btnStartTask1.setMnemonic('S');
  			btnStartTask1.setToolTipText("This task has autoshutdown policy of AppShutdown");
  			btnStartTask1.setHorizontalAlignment(SwingConstants.LEFT);
  			btnStartTask1.addActionListener(new ActionListener() {
  				public void actionPerformed(ActionEvent e) {
  					startTask1Action();
  				}
  			});
  			panel1.add(btnStartTask1, new TableLayoutConstraints(0, 0, 0, 0, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));

  			//---- label1 ----
  			label1.setText("Fire AutoShutdown signal:");
  			label1.setHorizontalAlignment(SwingConstants.CENTER);
  			label1.setHorizontalTextPosition(SwingConstants.RIGHT);
  			panel1.add(label1, new TableLayoutConstraints(2, 0, 3, 0, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));

  			//---- btnClearStatus ----
  			btnClearStatus.setText("Clear status");
  			btnClearStatus.setMnemonic('L');
  			btnClearStatus.setHorizontalTextPosition(SwingConstants.RIGHT);
  			btnClearStatus.setHorizontalAlignment(SwingConstants.LEFT);
  			btnClearStatus.addActionListener(new ActionListener() {
  				public void actionPerformed(ActionEvent e) {
  					clearSystemOut();
  				}
  			});
  			panel1.add(btnClearStatus, new TableLayoutConstraints(5, 0, 5, 0, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));

  			//---- btnShutdownManager ----
  			btnShutdownManager.setText("shutdownAll()");
  			btnShutdownManager.setHorizontalAlignment(SwingConstants.LEFT);
  			btnShutdownManager.addActionListener(new ActionListener() {
  				public void actionPerformed(ActionEvent e) {
  					shutdownAllAction();
  				}
  			});
  			panel1.add(btnShutdownManager, new TableLayoutConstraints(0, 1, 0, 1, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));

  			//---- listAutoShutdownSignals ----
  			listAutoShutdownSignals.setBackground(new Color(244, 247, 252));
  			listAutoShutdownSignals.setBorder(new EtchedBorder());
  			listAutoShutdownSignals.setToolTipText("<html>Selecting any of these items will result<br>in autoShutdownOn to be called on the TaskManager<br>to stop tasks with this autoshutdown policy</html>");
  			listAutoShutdownSignals.addListSelectionListener(new ListSelectionListener() {
  				public void valueChanged(ListSelectionEvent e) {
  					autoShutdownListChanged(e);
  				}
  			});
  			panel1.add(listAutoShutdownSignals, new TableLayoutConstraints(2, 1, 3, 2, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));

  			//---- btnQuit ----
  			btnQuit.setText("Quit");
  			btnQuit.setMnemonic('Q');
  			btnQuit.setHorizontalAlignment(SwingConstants.LEFT);
  			btnQuit.setHorizontalTextPosition(SwingConstants.RIGHT);
  			btnQuit.addActionListener(new ActionListener() {
  				public void actionPerformed(ActionEvent e) {
  					quitProgram();
  				}
  			});
  			panel1.add(btnQuit, new TableLayoutConstraints(5, 1, 5, 1, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));

  			//---- cboxIsOnline ----
  			cboxIsOnline.setText("Is Online");
  			cboxIsOnline.setSelected(true);
  			cboxIsOnline.setOpaque(false);
  			cboxIsOnline.setHorizontalAlignment(SwingConstants.CENTER);
  			cboxIsOnline.setToolTipText("Put TaskManager in Online or Offline mode");
  			cboxIsOnline.addItemListener(new ItemListener() {
  				public void itemStateChanged(ItemEvent e) {
  					cboxIsOnlineItemStateChanged();
  				}
  			});
  			panel1.add(cboxIsOnline, new TableLayoutConstraints(0, 2, 0, 2, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));
  		}
  		contentPanel.add(panel1, new TableLayoutConstraints(0, 0, 0, 0, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));

  		//======== taskPanel ========
  		{
  			taskPanel.setOpaque(true);
  			taskPanel.setLayout(new GridLayout(3, 1));
  		}
  		contentPanel.add(taskPanel, new TableLayoutConstraints(0, 1, 0, 1, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));

  		//======== scrollPane1 ========
  		{
  			scrollPane1.setBorder(new TitledBorder("System.out - displays all status and progress messages, etc."));
  			scrollPane1.setOpaque(false);

  			//---- ttaStatus ----
  			ttaStatus.setBorder(Borders.createEmptyBorder("1dlu, 1dlu, 1dlu, 1dlu"));
  			ttaStatus.setToolTipText("<html>Task progress updates (messages) are displayed here,<br>along with any other output generated by the Task.<html>");
  			ttaStatus.setRows(4);
  			scrollPane1.setViewportView(ttaStatus);
  		}
  		contentPanel.add(scrollPane1, new TableLayoutConstraints(0, 2, 0, 2, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));
  	}
  	dialogPane.add(contentPanel, BorderLayout.CENTER);
  }
  contentPane.add(dialogPane, BorderLayout.CENTER);
  setSize(675, 535);
  setLocationRelativeTo(null);
  // JFormDesigner - End of component initialization  //GEN-END:initComponents
}

// JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
// Generated using JFormDesigner non-commercial license
private GradientPanel dialogPane;
private JPanel contentPanel;
private JPanel panel1;
private JButton btnStartTask1;
private JLabel label1;
private JButton btnClearStatus;
private JButton btnShutdownManager;
private JList listAutoShutdownSignals;
private JButton btnQuit;
private JCheckBox cboxIsOnline;
private GradientPanel taskPanel;
private JScrollPane scrollPane1;
private JTextArea ttaStatus;
// JFormDesigner - End of variables declaration  //GEN-END:variables
}