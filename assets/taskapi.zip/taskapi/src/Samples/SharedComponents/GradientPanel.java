package Samples.SharedComponents;

import Task.Support.GUISupport.*;

import javax.swing.*;
import java.awt.*;

/**
 * GradientPanel
 *
 * @author Nazmul Idris
 * @version 1.0
 * @since Mar 27, 2008, 1:14:49 PM
 */
public class GradientPanel extends JPanel {

public GradientPanel() {
  super();
  setOpaque(false);
}

@Override public void paintComponent(Graphics g)
{
  Graphics2D g2 = ImageUtils.g2(g);

  DrawingUtils.drawShadeFast(
      g, getWidth(), getHeight(),
//      new Color[]{Colors.LightGray.color(0.3f), Colors.Gray.color(0.3f)},
      new Color[]{Colors.LightGrad_LightStop.color(1f), Colors.LightGrad_DarkStop.color(1f)},
      1f
  );

  g2.dispose();
}


}//end class GradientPanel

