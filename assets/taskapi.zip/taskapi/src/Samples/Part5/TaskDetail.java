/*
 * Created by JFormDesigner on Tue Apr 01 13:21:46 EDT 2008
 */

package Samples.Part5;

import java.awt.*;
import info.clearthought.layout.*;

import javax.swing.*;
import javax.swing.border.*;

/**
 * @author nazmul idris
 */
public class TaskDetail extends JPanel {
	public TaskDetail() {
		initComponents();
	}

	private void initComponents() {
		// JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
		// Generated using JFormDesigner non-commercial license
		label1 = new JLabel();
		ttfName = new JTextField();
		label2 = new JLabel();
		ttfDescription = new JTextField();
		label5 = new JLabel();
		ttfProgressMessage = new JTextField();
		label4 = new JLabel();
		progressBar = new JProgressBar();
		label3 = new JLabel();
		ttfStatus = new JTextField();

		//======== this ========
		setBorder(new EtchedBorder());
		setOpaque(false);
		setFont(this.getFont().deriveFont(this.getFont().getSize() - 2f));
		setPreferredSize(new Dimension(348, 59));
		setLayout(new TableLayout(new double[][] {
			{TableLayout.PREFERRED, 0.4, TableLayout.PREFERRED, TableLayout.FILL},
			{TableLayout.PREFERRED, TableLayout.PREFERRED, TableLayout.PREFERRED}}));
		((TableLayout)getLayout()).setHGap(5);
		((TableLayout)getLayout()).setVGap(5);

		//---- label1 ----
		label1.setText("Name");
		label1.setFont(label1.getFont().deriveFont(label1.getFont().getSize() - 2f));
		add(label1, new TableLayoutConstraints(0, 0, 0, 0, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));

		//---- ttfName ----
		ttfName.setFont(ttfName.getFont().deriveFont(ttfName.getFont().getSize() - 2f));
		ttfName.setBackground(UIManager.getColor("Button.background"));
		add(ttfName, new TableLayoutConstraints(1, 0, 1, 0, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));

		//---- label2 ----
		label2.setText("Description");
		label2.setFont(label2.getFont().deriveFont(label2.getFont().getSize() - 2f));
		add(label2, new TableLayoutConstraints(2, 0, 2, 0, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));

		//---- ttfDescription ----
		ttfDescription.setFont(ttfDescription.getFont().deriveFont(ttfDescription.getFont().getSize() - 2f));
		ttfDescription.setBackground(UIManager.getColor("Button.background"));
		add(ttfDescription, new TableLayoutConstraints(3, 0, 3, 0, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));

		//---- label5 ----
		label5.setText("Progress");
		label5.setFont(label5.getFont().deriveFont(label5.getFont().getSize() - 2f));
		add(label5, new TableLayoutConstraints(0, 1, 0, 1, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));

		//---- ttfProgressMessage ----
		ttfProgressMessage.setFont(ttfProgressMessage.getFont().deriveFont(ttfProgressMessage.getFont().getSize() - 2f));
		ttfProgressMessage.setBackground(UIManager.getColor("Button.background"));
		add(ttfProgressMessage, new TableLayoutConstraints(1, 1, 1, 1, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));

		//---- label4 ----
		label4.setText("Progress");
		label4.setFont(label4.getFont().deriveFont(label4.getFont().getSize() - 2f));
		add(label4, new TableLayoutConstraints(2, 1, 2, 1, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));

		//---- progressBar ----
		progressBar.setFont(progressBar.getFont().deriveFont(progressBar.getFont().getSize() - 2f));
		add(progressBar, new TableLayoutConstraints(3, 1, 3, 1, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));

		//---- label3 ----
		label3.setText("Status");
		label3.setFont(label3.getFont().deriveFont(label3.getFont().getSize() - 2f));
		add(label3, new TableLayoutConstraints(0, 2, 0, 2, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));

		//---- ttfStatus ----
		ttfStatus.setFont(ttfStatus.getFont().deriveFont(ttfStatus.getFont().getSize() - 2f));
		ttfStatus.setBackground(UIManager.getColor("Button.background"));
		add(ttfStatus, new TableLayoutConstraints(1, 2, 3, 2, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));
		// JFormDesigner - End of component initialization  //GEN-END:initComponents
	}

	// JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
	// Generated using JFormDesigner non-commercial license
	private JLabel label1;
	public JTextField ttfName;
	private JLabel label2;
	public JTextField ttfDescription;
	private JLabel label5;
	public JTextField ttfProgressMessage;
	private JLabel label4;
	public JProgressBar progressBar;
	private JLabel label3;
	public JTextField ttfStatus;
	// JFormDesigner - End of variables declaration  //GEN-END:variables
}
