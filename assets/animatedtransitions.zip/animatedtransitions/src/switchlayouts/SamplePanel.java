/*
 * Created by JFormDesigner on Mon Sep 24 13:06:57 EDT 2007
 */

package switchlayouts;

import info.clearthought.layout.TableLayout;
import info.clearthought.layout.TableLayoutConstraints;
import org.jdesktop.animation.timing.Animator;
import org.jdesktop.animation.timing.interpolation.SplineInterpolator;
import org.jdesktop.animation.transitions.ScreenTransition;
import org.jdesktop.animation.transitions.TransitionTarget;
import org.jdesktop.swingx.JXButton;
import org.jdesktop.swingx.JXLabel;
import org.jdesktop.swingx.JXPanel;

import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

/**
 * @author nazmul idris
 */
public class SamplePanel extends JXPanel implements TransitionTarget {
    public SamplePanel() {
        initComponents();

        // -- create the animator object (set delay and interpolator)
        Animator anim = new Animator(200);
        // http://javadesktop.org/swinglabs/demos/timingframework/SplineEditor.jnlp
        anim.setInterpolator(new SplineInterpolator(
                0.00f, 1.00f,
                1.00f, 0.98f));

        // -- setup the screen transition object, with TransitionTarget & Animator
        st = new ScreenTransition(
                contentPanel,
                this,
                anim
        );

    }

    // -- data members...
    ScreenTransition st;

    enum Layouts {
        Wide, Tall
    }

    Layouts currentLayout = Layouts.Wide;
    Layouts newLayout = null;

    public void setupNextScreen() {

        contentPanel.removeAll();

        switch (newLayout) {
            case Tall: // -- do Tall layout...
                TableLayout tallLayout = new TableLayout(new double[][]{
                        {0.3, TableLayout.FILL},
                        {0.5, 0.5}});
                tallLayout.setHGap(5);
                tallLayout.setVGap(5);
                contentPanel.setLayout(tallLayout);
                contentPanel.add(leftLabel, new TableLayoutConstraints(0, 0, 0, 1, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));
                contentPanel.add(middleLabel, new TableLayoutConstraints(1, 0, 1, 0, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));
                contentPanel.add(rightLabel, new TableLayoutConstraints(1, 1, 1, 1, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));
                break;
            case Wide: // -- do Wide layout
                TableLayout wideLayout = new TableLayout(new double[][]{
                        {0.33, 0.33, TableLayout.FILL},
                        {TableLayout.FILL}});
                wideLayout.setHGap(5);
                wideLayout.setVGap(5);
                contentPanel.setLayout(wideLayout);
                contentPanel.add(leftLabel, new TableLayoutConstraints(0, 0, 0, 0, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));
                contentPanel.add(middleLabel, new TableLayoutConstraints(1, 0, 1, 0, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));
                contentPanel.add(rightLabel, new TableLayoutConstraints(2, 0, 2, 0, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));
                break;
        }

        contentPanel.revalidate();
        contentPanel.repaint();

        currentLayout = newLayout;
        newLayout = null;
    }

    /**
     * check to see if the layout needs to be changed. if it does need to be changed
     * then start the ScreenTransition and pre-set the necessary values.
     *
     * @param newLayout
     */
    private void layoutNeedsToBeChanged(Layouts newLayout) {
        if (newLayout == null) return;
        if (newLayout == currentLayout) {
            this.newLayout = null;
            return;
        }
        this.newLayout = newLayout;
        st.start();
    }

    private void switchToWideLayout(ActionEvent e) {
        layoutNeedsToBeChanged(Layouts.Wide);
    }

    private void switchToTallLayout(ActionEvent e) {
        layoutNeedsToBeChanged(Layouts.Tall);
    }

    // -- JFormDesigner stuff
    private void initComponents() {
        // JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
        // Generated using JFormDesigner non-commercial license
        buttonPanel = new JXPanel();
        xLabel1 = new JXLabel();
        xButton1 = new JXButton();
        xButton2 = new JXButton();
        contentPanel = new JXPanel();
        leftLabel = new JXLabel();
        middleLabel = new JXLabel();
        rightLabel = new JXLabel();

        //======== this ========
        setLayout(new BorderLayout(5, 5));

        //======== buttonPanel ========
        {
            buttonPanel.setLayout(new FlowLayout());
            ((FlowLayout) buttonPanel.getLayout()).setAlignOnBaseline(true);

            //---- xLabel1 ----
            xLabel1.setText("Switch to:");
            buttonPanel.add(xLabel1);

            //---- xButton1 ----
            xButton1.setText("Wide Layout");
            xButton1.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    switchToWideLayout(e);
                }
            });
            buttonPanel.add(xButton1);

            //---- xButton2 ----
            xButton2.setText("Tall Layout");
            xButton2.addActionListener(new ActionListener() {
                public void actionPerformed(ActionEvent e) {
                    switchToTallLayout(e);
                }
            });
            buttonPanel.add(xButton2);
        }
        add(buttonPanel, BorderLayout.SOUTH);

        //======== contentPanel ========
        {
            contentPanel.setLayout(new TableLayout(new double[][]{
                    {0.33, 0.33, TableLayout.FILL},
                    {TableLayout.FILL}}));
            ((TableLayout) contentPanel.getLayout()).setHGap(5);
            ((TableLayout) contentPanel.getLayout()).setVGap(5);

            //---- leftLabel ----
            leftLabel.setText("Left");
            contentPanel.add(leftLabel, new TableLayoutConstraints(0, 0, 0, 0, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));

            //---- middleLabel ----
            middleLabel.setText("Middle");
            contentPanel.add(middleLabel, new TableLayoutConstraints(1, 0, 1, 0, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));

            //---- rightLabel ----
            rightLabel.setText("Right");
            contentPanel.add(rightLabel, new TableLayoutConstraints(2, 0, 2, 0, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));
        }
        add(contentPanel, BorderLayout.CENTER);
        // JFormDesigner - End of component initialization  //GEN-END:initComponents
    }

    // JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
    // Generated using JFormDesigner non-commercial license
    private JXPanel buttonPanel;
    private JXLabel xLabel1;
    private JXButton xButton1;
    private JXButton xButton2;
    private JXPanel contentPanel;
    private JXLabel leftLabel;
    private JXLabel middleLabel;
    private JXLabel rightLabel;
    // JFormDesigner - End of variables declaration  //GEN-END:variables
}
