/*
 * Created by JFormDesigner on Thu Mar 27 12:38:02 EDT 2008
 */

package Samples.Part4;

import Samples.SharedComponents.*;
import Task.*;
import Task.Manager.*;
import Task.ProgressMonitor.*;
import Task.Support.CoreSupport.Utils;
import Task.Support.GUISupport.*;
import com.jgoodies.forms.factories.*;
import info.clearthought.layout.*;
import weather_service.weatherprovider.*;
import weather_service.weatherprovider.weatherdatamodel.*;

import javax.swing.*;
import javax.swing.border.*;
import javax.swing.text.*;
import java.awt.*;
import java.awt.event.*;
import java.awt.image.*;
import java.beans.*;
import java.text.*;
import java.util.concurrent.*;

/** @author nazmul idris */
public class SampleApp extends JFrame {
//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
// data members
//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
/** reference to task */
private RecurringNetworkTask _task;
/** task manager for all tasks */
private TaskManager _taskManager = new TaskManager();

//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
// main method...
//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

public static void main(String[] args) {
  Utils.createInEDT(SampleApp.class);
}

//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
// constructor
//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

private void doInit() {
  GUIUtils.setAppIcon(this, "burn.png");
  GUIUtils.centerOnScreen(this);
  setVisible(true);

  int W = 28, H = W;
  boolean blur = false;
  float alpha = .7f;

  try {
    btnRestartWithNewDelay.setIcon(ImageUtils.loadScaledBufferedIcon("schedule.png", W, H, blur, alpha));
    btnStartWithDefaultDelay.setIcon(ImageUtils.loadScaledBufferedIcon("schedule.png", W, H, blur, alpha));
    btnStartWithGivenDelay.setIcon(ImageUtils.loadScaledBufferedIcon("schedule.png", W, H, blur, alpha));
    btnStopRecurring.setIcon(ImageUtils.loadScaledBufferedIcon("schedule.png", W, H, blur, alpha));
    btnStart.setIcon(ImageUtils.loadScaledBufferedIcon("ok1.png", W, H, blur, alpha));
    btnCancelTask.setIcon(ImageUtils.loadScaledBufferedIcon("alert-stop.png", W, H, blur, alpha));
    btnShutdown.setIcon(ImageUtils.loadScaledBufferedIcon("exit.png", W, H, blur, alpha));
    btnClearStatus.setIcon(ImageUtils.loadScaledBufferedIcon("bulb.png", W, H, blur, alpha));
    btnQuit.setIcon(ImageUtils.loadScaledBufferedIcon("charging.png", W, H, blur, alpha));
  }
  catch (Exception e) {
    System.out.println(e);
  }

  // setup the textfield masks
  try {
    ttfZipCode.setFormatterFactory(new DefaultFormatterFactory(new MaskFormatter("#####")));
    ttfDelay.setFormatterFactory(new DefaultFormatterFactory(new NumberFormatter(NumberFormat.getIntegerInstance())));
    ttfZipCode.setText("20166");
    ttfDelay.setText("30");
  }
  catch (ParseException e) {
    System.out.println(e);
  }

  _setupTask();
}

/** create a test task and wire it up with a task handler that dumps output to the textarea */
@SuppressWarnings("unchecked")
private void _setupTask() {

  TaskExecutorIF<WeatherReport> functor = new TaskExecutorAdapter<WeatherReport>() {
    public WeatherReport doInBackground(Future<WeatherReport> swingWorker, SwingUIHookAdapter hook) throws Exception {

      try {

        _initHook(hook);

        WeatherGateway gateway = new WeatherGateway(new DefaultWeatherConfigurationBean());
        gateway.setUIHook(hook);
        WeatherReport report = gateway.getCurrentConditions(ttfZipCode.getText());

        return report;

      }
      catch (Exception e) {
        e.printStackTrace();
        throw e;
      }

    }

    @Override public String getName() {
      return _task.getName();
    }
  };

  _task = new RecurringNetworkTask(_taskManager,
                                   functor,
                                   "Recurring weather retrieval task",
                                   "Loads weather.com data every few seconds",
                                   AutoShutdownSignals.Daemon);

  _task.addStatusListener(new PropertyChangeListener() {
    public void propertyChange(PropertyChangeEvent evt) {
      sout(":: task status change - " + evt.getNewValue().toString());
      lblProgressStatus.setText(evt.getNewValue().toString());
    }

  });

  _task.setTaskHandler(new
      NetworkTaskHandler<WeatherReport>() {
        /** {@inheritDoc} */
        @Override public void shutdownCalled(AbstractTask task) {
          sout(":: taskHandler [" + task.getName() + "]- shutdownCalled");
        }
        @Override public void beforeStart(AbstractTask task) {
          sout(":: taskHandler [" + task.getName() + "]- beforeStart");
        }
        @Override public void started(AbstractTask task) {
          sout(":: taskHandler [" + task.getName() + "]- started");
        }
        /** {@link SampleApp#_initHook} adds the task status listener, which is removed here */
        @Override public void stopped(long time, AbstractTask task) {
          sout(":: taskHandler [" + task.getName() + "]- stopped");
          sout(":: time = " + time / 1000f + "sec");
          task.getUIHook().clearAllStatusListeners();
        }
        @Override public void interrupted(Throwable e, AbstractTask task) {
          sout(":: taskHandler [" + task.getName() + "]- interrupted - " + e.toString());
        }
        @Override public void ok(WeatherReport value, long time, AbstractTask task) {
          sout(":: taskHandler [" + task.getName() + "]- ok - WeatherReport=" + (value == null
                                                                                 ? "null"
                                                                                 : value.toString()));
          _displayDataInFrame(value);

        }
        @Override public void error(Throwable e, long time, AbstractTask task) {
          sout(":: taskHandler [" + task.getName() + "]- error - " + e.toString());
        }
        @Override public void cancelled(long time, AbstractTask task) {
          sout(" :: taskHandler [" + task.getName() + "]- cancelled");
        }
        /** {@inheritDoc} */
        @Override public void notOnline(AbstractTask task) {
          sout(":: taskHandler [" + task.getName() + "]- is not online. TaskExecutor did not run.");
        }
      }//end NetworkTaskHandler
  );
}

private SwingUIHookAdapter _initHook(SwingUIHookAdapter hook) {
  hook.enableRecieveStatusNotification(checkboxRecvStatus.isSelected());
  hook.enableSendStatusNotification(checkboxSendStatus.isSelected());

  hook.setProgressMessage(ttfProgressMsg.getText());

  PropertyChangeListener listener = new PropertyChangeListener() {
    public void propertyChange(PropertyChangeEvent evt) {
      SwingUIHookAdapter.PropertyList type = ProgressMonitorUtils.parseTypeFrom(evt);
      int progress = ProgressMonitorUtils.parsePercentFrom(evt);
      String msg = ProgressMonitorUtils.parseMessageFrom(evt);

      progressBar.setValue(progress);
      progressBar.setString(type.toString());

      sout(msg);
    }
  };

  hook.addRecieveStatusListener(listener);
  hook.addSendStatusListener(listener);
  hook.addUnderlyingIOStreamInterruptedOrClosed(new PropertyChangeListener() {
    public void propertyChange(PropertyChangeEvent evt) {
      sout(evt.getPropertyName() + " fired!!!");
    }
  });

  return hook;
}

private void _displayDataInFrame(WeatherReport data) {

  final JFrame frame = new JFrame("Weather Report");
  GUIUtils.setAppIcon(frame, "71.png");
  frame.setDefaultCloseOperation(DISPOSE_ON_CLOSE);

  WeatherDisplay display = new WeatherDisplay();


  display.getCurrentTempTTF().setText(data.getCurrentConditions().getTemperature() +
                                      data.getHeader().getTemperatureUnit()
  );
  display.getFeelsLikeTTF().setText(data.getCurrentConditions().getFeelsLikeTemperature() +
                                    data.getHeader().getTemperatureUnit()
  );
  try {
    BufferedImage weatherImage = ImageUtils.loadBufferedImage(data.getCurrentConditions().getIcon() + ".png",
                                                              false,
                                                              0.9f);
    BufferedImage reflectionImage = DrawingUtils.getReflection(weatherImage, 0.5f, 0.5f, true);

    display.getWeatherLabel().setIcon(
        new ImageIcon(reflectionImage)
    );
  }
  catch (ClassNotFoundException e) {
    System.out.println(e);
  }

  display.addMouseListener(new MouseAdapter() {
    @Override public void mouseClicked(MouseEvent e) {
      frame.dispose();
    }
  });

  frame.setContentPane(new JScrollPane(display));
  frame.pack();

  GUIUtils.centerOnScreen(frame);
  frame.setVisible(true);
}

/** simply dump status info to the textarea */
private void sout(final String s) {
  Runnable soutRunner = new Runnable() {
    public void run() {
      if (ttaStatus.getText().equals("")) {
        ttaStatus.setText(s);
      }
      else {
        ttaStatus.setText(ttaStatus.getText() + "\n" + s);
      }
    }
  };

  if (ThreadUtils.isInEDT()) {
    soutRunner.run();
  }
  else {
    SwingUtilities.invokeLater(soutRunner);
  }
}

//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
// actions wired to the UI
//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

private void stopRecurringAction() {
  _task.stopRecurring();
}

private void setDelayAction() {
  _task.setRefreshDelay(
      Integer.parseInt(
          ttfDelay.getText()
      ));
}

private void startWithDefaultDelayAction() {
  try {
    _task.start();
  }
  catch (TaskException e) {
    sout(e.getMessage());
  }
}

private void startWithGivenDelayAction() {
  try {
    _task.start(Integer.parseInt(
        ttfDelay.getText()
    ));
  }
  catch (TaskException e) {
    sout(e.getMessage());
  }
}

private void restartWithNewDelayAction() {
  try {
    _task.restartWithNewDelay(Integer.parseInt(
        ttfDelay.getText()
    ));
  }
  catch (TaskException e) {
    sout(e.getMessage());
  }
}

private void executeTask() {
  try {
    _task.execute();
  }
  catch (TaskException e) {
    sout(e.getMessage());
  }
}

private void cancelTaskAction() {
  _task.cancel();
}

private void shutdownTaskAction() {
  _task.shutdown();
}

private void quitProgram() {
  _task.shutdown();
  System.exit(0);
}

private void clearSystemOut() {
  ttaStatus.setText(null);
}

//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
// JFormDesigner generated stuff...
//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

public SampleApp() {
  initComponents();
  doInit();
}

private void checkBoxIsOnlineChanged() {
  if (checkBoxIsOnline.isSelected()) {
    _taskManager.online();
  }
  else {
    _taskManager.offline();
  }
}

private void initComponents() {
  // JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
  // Generated using JFormDesigner non-commercial license
  dialogPane = new GradientPanel();
  contentPanel = new JPanel();
  panel1 = new JPanel();
  btnStartWithDefaultDelay = new JButton();
  btnStartWithGivenDelay = new JButton();
  btnStart = new JButton();
  btnClearStatus = new JButton();
  btnRestartWithNewDelay = new JButton();
  btnCancelTask = new JButton();
  btnQuit = new JButton();
  btnStopRecurring = new JButton();
  btnShutdown = new JButton();
  label2 = new JLabel();
  label1 = new JLabel();
  ttfDelay = new JFormattedTextField();
  btnSetRefreshDelay = new JButton();
  ttfZipCode = new JFormattedTextField();
  checkBoxIsOnline = new JCheckBox();
  scrollPane1 = new JScrollPane();
  ttaStatus = new JTextArea();
  panel2 = new JPanel();
  panel3 = new JPanel();
  checkboxRecvStatus = new JCheckBox();
  checkboxSendStatus = new JCheckBox();
  ttfProgressMsg = new JTextField();
  progressBar = new JProgressBar();
  lblProgressStatus = new JLabel();

  //======== this ========
  setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
  setTitle("Part 4 - Using Recurring Network Tasks. Periodically retrieving weather forecast.");
  setIconImage(null);
  Container contentPane = getContentPane();
  contentPane.setLayout(new BorderLayout());

  //======== dialogPane ========
  {
    dialogPane.setBorder(new EmptyBorder(12, 12, 12, 12));
    dialogPane.setOpaque(false);
    dialogPane.setLayout(new BorderLayout());

    //======== contentPanel ========
    {
      contentPanel.setOpaque(false);
      contentPanel.setLayout(new TableLayout(new double[][]{
          {TableLayout.FILL},
          {TableLayout.PREFERRED, TableLayout.PREFERRED, TableLayout.FILL, TableLayout.PREFERRED}}));
      ((TableLayout) contentPanel.getLayout()).setHGap(5);
      ((TableLayout) contentPanel.getLayout()).setVGap(5);

      //======== panel1 ========
      {
        panel1.setOpaque(false);
        panel1.setBorder(new CompoundBorder(
            new TitledBorder("Task Control - start, cancel, stop, restart RecurringNetworkTask"),
            Borders.DLU2_BORDER));
        panel1.setLayout(new TableLayout(new double[][]{
            {0.25, 0.25, 0.25, 0.25, TableLayout.FILL, TableLayout.PREFERRED},
            {TableLayout.PREFERRED, TableLayout.PREFERRED, TableLayout.PREFERRED, TableLayout.PREFERRED,
             TableLayout.PREFERRED}}));
        ((TableLayout) panel1.getLayout()).setHGap(5);
        ((TableLayout) panel1.getLayout()).setVGap(5);

        //---- btnStartWithDefaultDelay ----
        btnStartWithDefaultDelay.setText("start()");
        btnStartWithDefaultDelay.setMnemonic('S');
        btnStartWithDefaultDelay.setToolTipText(
            "<html>Start recurring task with default delay<br>(you can set the default using Set <u>d</u>elay).</html>");
        btnStartWithDefaultDelay.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            startWithDefaultDelayAction();
          }
        });
        panel1.add(btnStartWithDefaultDelay,
                   new TableLayoutConstraints(0, 0, 0, 0, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));

        //---- btnStartWithGivenDelay ----
        btnStartWithGivenDelay.setText("start(int)");
        btnStartWithGivenDelay.setMnemonic('R');
        btnStartWithGivenDelay.setToolTipText("Start task with given delay (in UI)");
        btnStartWithGivenDelay.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            startWithGivenDelayAction();
          }
        });
        panel1.add(btnStartWithGivenDelay,
                   new TableLayoutConstraints(1, 0, 1, 0, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));

        //---- btnStart ----
        btnStart.setText("execute()");
        btnStart.setMnemonic('T');
        btnStart.setToolTipText("Execute the NetworkTask once, don't start the recurring task");
        btnStart.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            executeTask();
          }
        });
        panel1.add(btnStart,
                   new TableLayoutConstraints(2, 0, 3, 0, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));

        //---- btnClearStatus ----
        btnClearStatus.setText("Clear status");
        btnClearStatus.setMnemonic('L');
        btnClearStatus.setHorizontalTextPosition(SwingConstants.RIGHT);
        btnClearStatus.setHorizontalAlignment(SwingConstants.LEFT);
        btnClearStatus.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            clearSystemOut();
          }
        });
        panel1.add(btnClearStatus,
                   new TableLayoutConstraints(5, 0, 5, 0, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));

        //---- btnRestartWithNewDelay ----
        btnRestartWithNewDelay.setText("restartWithNewDelay(int)");
        btnRestartWithNewDelay.setToolTipText("If task is running, then stop it, and restart it with the given delay.");
        btnRestartWithNewDelay.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            restartWithNewDelayAction();
          }
        });
        panel1.add(btnRestartWithNewDelay,
                   new TableLayoutConstraints(0, 1, 1, 1, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));

        //---- btnCancelTask ----
        btnCancelTask.setText("cancel()");
        btnCancelTask.setMnemonic('C');
        btnCancelTask.setToolTipText(
            "<html>Cancels currently executing thread performing this task.<br>More threads will be spawed after delay.</html>");
        btnCancelTask.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            cancelTaskAction();
          }
        });
        panel1.add(btnCancelTask,
                   new TableLayoutConstraints(2, 1, 3, 1, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));

        //---- btnQuit ----
        btnQuit.setText("Quit");
        btnQuit.setMnemonic('Q');
        btnQuit.setHorizontalAlignment(SwingConstants.LEFT);
        btnQuit.setHorizontalTextPosition(SwingConstants.RIGHT);
        btnQuit.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            quitProgram();
          }
        });
        panel1.add(btnQuit,
                   new TableLayoutConstraints(5, 1, 5, 1, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));

        //---- btnStopRecurring ----
        btnStopRecurring.setText("stopRecurring()");
        btnStopRecurring.setMnemonic('E');
        btnStopRecurring.setToolTipText("Stops the task recurrance. Does NOT shutdown the task.");
        btnStopRecurring.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            stopRecurringAction();
          }
        });
        panel1.add(btnStopRecurring,
                   new TableLayoutConstraints(0, 2, 1, 2, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));

        //---- btnShutdown ----
        btnShutdown.setText("shutdown()");
        btnShutdown.setMnemonic('U');
        btnShutdown.setToolTipText(
            "<html>Shutdown the recurring task. Once shutdown<br>the task can be restarted or executed anymore.</html>");
        btnShutdown.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            shutdownTaskAction();
          }
        });
        panel1.add(btnShutdown,
                   new TableLayoutConstraints(2, 2, 3, 2, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));

        //---- label2 ----
        label2.setText("Delay (in sec)");
        panel1.add(label2,
                   new TableLayoutConstraints(0, 3, 0, 3, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));

        //---- label1 ----
        label1.setText("Zip code");
        panel1.add(label1,
                   new TableLayoutConstraints(3, 3, 3, 3, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));

        //---- ttfDelay ----
        ttfDelay.setToolTipText("delay is in seconds");
        panel1.add(ttfDelay,
                   new TableLayoutConstraints(0, 4, 0, 4, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));

        //---- btnSetRefreshDelay ----
        btnSetRefreshDelay.setText("Set delay");
        btnSetRefreshDelay.setMnemonic('D');
        btnSetRefreshDelay.setToolTipText(
            "<html>Set delay on the recurring task. Once started,<br>setting this won't change anything.<br>You have to restart the task for this to take effect.</html>");
        btnSetRefreshDelay.addActionListener(new ActionListener() {
          public void actionPerformed(ActionEvent e) {
            setDelayAction();
          }
        });
        panel1.add(btnSetRefreshDelay,
                   new TableLayoutConstraints(1, 4, 1, 4, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));

        //---- ttfZipCode ----
        ttfZipCode.setToolTipText("5 digit zip code");
        panel1.add(ttfZipCode,
                   new TableLayoutConstraints(3, 4, 3, 4, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));

        //---- checkBoxIsOnline ----
        checkBoxIsOnline.setText("Is Online");
        checkBoxIsOnline.setOpaque(false);
        checkBoxIsOnline.setToolTipText(
            "<html>Set whether Network task should run or not.<br>Network tasks don't run when \"isOnline\" is <b>false</b>.</html>");
        checkBoxIsOnline.setSelected(true);
        checkBoxIsOnline.setMnemonic('O');
        checkBoxIsOnline.addItemListener(new ItemListener() {
          public void itemStateChanged(ItemEvent e) {
            checkBoxIsOnlineChanged();
          }
        });
        panel1.add(checkBoxIsOnline,
                   new TableLayoutConstraints(5, 4, 5, 4, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));
      }
      contentPanel.add(panel1,
                       new TableLayoutConstraints(0,
                                                  0,
                                                  0,
                                                  0,
                                                  TableLayoutConstraints.FULL,
                                                  TableLayoutConstraints.FULL));

      //======== scrollPane1 ========
      {
        scrollPane1.setBorder(new TitledBorder("System.out - displays all status and progress messages, etc."));
        scrollPane1.setOpaque(false);

        //---- ttaStatus ----
        ttaStatus.setBorder(Borders.createEmptyBorder("1dlu, 1dlu, 1dlu, 1dlu"));
        ttaStatus.setToolTipText(
            "<html>Task progress updates (messages) are displayed here,<br>along with any other output generated by the Task.<html>");
        ttaStatus.setRows(9);
        scrollPane1.setViewportView(ttaStatus);
      }
      contentPanel.add(scrollPane1,
                       new TableLayoutConstraints(0,
                                                  1,
                                                  0,
                                                  1,
                                                  TableLayoutConstraints.FULL,
                                                  TableLayoutConstraints.FULL));

      //======== panel2 ========
      {
        panel2.setOpaque(false);
        panel2.setBorder(new CompoundBorder(
            new TitledBorder("Status - control progress reporting"),
            Borders.DLU2_BORDER));
        panel2.setLayout(new TableLayout(new double[][]{
            {0.45, TableLayout.FILL, 0.45},
            {TableLayout.PREFERRED, TableLayout.PREFERRED}}));
        ((TableLayout) panel2.getLayout()).setHGap(5);
        ((TableLayout) panel2.getLayout()).setVGap(5);

        //======== panel3 ========
        {
          panel3.setOpaque(false);
          panel3.setLayout(new GridLayout(1, 2));

          //---- checkboxRecvStatus ----
          checkboxRecvStatus.setText("Enable \"Recieve\"");
          checkboxRecvStatus.setOpaque(false);
          checkboxRecvStatus.setToolTipText("Task will fire \"send\" status updates");
          checkboxRecvStatus.setSelected(true);
          panel3.add(checkboxRecvStatus);

          //---- checkboxSendStatus ----
          checkboxSendStatus.setText("Enable \"Send\"");
          checkboxSendStatus.setOpaque(false);
          checkboxSendStatus.setToolTipText("Task will fire \"recieve\" status updates");
          panel3.add(checkboxSendStatus);
        }
        panel2.add(panel3,
                   new TableLayoutConstraints(0, 0, 0, 0, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));

        //---- ttfProgressMsg ----
        ttfProgressMsg.setText("Getting weather forecast from weather.com");
        ttfProgressMsg.setToolTipText("Set the task progress message here");
        panel2.add(ttfProgressMsg,
                   new TableLayoutConstraints(2, 0, 2, 0, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));

        //---- progressBar ----
        progressBar.setStringPainted(true);
        progressBar.setString("progress %");
        progressBar.setToolTipText("% progress is displayed here");
        panel2.add(progressBar,
                   new TableLayoutConstraints(0, 1, 0, 1, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));

        //---- lblProgressStatus ----
        lblProgressStatus.setText("task status listener");
        lblProgressStatus.setHorizontalTextPosition(SwingConstants.LEFT);
        lblProgressStatus.setHorizontalAlignment(SwingConstants.LEFT);
        lblProgressStatus.setToolTipText("Task status messages are displayed here when the task runs");
        panel2.add(lblProgressStatus,
                   new TableLayoutConstraints(2, 1, 2, 1, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));
      }
      contentPanel.add(panel2,
                       new TableLayoutConstraints(0,
                                                  3,
                                                  0,
                                                  3,
                                                  TableLayoutConstraints.FULL,
                                                  TableLayoutConstraints.FULL));
    }
    dialogPane.add(contentPanel, BorderLayout.CENTER);
  }
  contentPane.add(dialogPane, BorderLayout.CENTER);
  setSize(675, 545);
  setLocationRelativeTo(null);
  // JFormDesigner - End of component initialization  //GEN-END:initComponents
}

// JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
// Generated using JFormDesigner non-commercial license
private GradientPanel dialogPane;
private JPanel contentPanel;
private JPanel panel1;
private JButton btnStartWithDefaultDelay;
private JButton btnStartWithGivenDelay;
private JButton btnStart;
private JButton btnClearStatus;
private JButton btnRestartWithNewDelay;
private JButton btnCancelTask;
private JButton btnQuit;
private JButton btnStopRecurring;
private JButton btnShutdown;
private JLabel label2;
private JLabel label1;
private JFormattedTextField ttfDelay;
private JButton btnSetRefreshDelay;
private JFormattedTextField ttfZipCode;
private JCheckBox checkBoxIsOnline;
private JScrollPane scrollPane1;
private JTextArea ttaStatus;
private JPanel panel2;
private JPanel panel3;
private JCheckBox checkboxRecvStatus;
private JCheckBox checkboxSendStatus;
private JTextField ttfProgressMsg;
private JProgressBar progressBar;
private JLabel lblProgressStatus;
// JFormDesigner - End of variables declaration  //GEN-END:variables
}