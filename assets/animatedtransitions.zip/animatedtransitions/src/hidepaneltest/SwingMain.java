package hidepaneltest;

import org.jdesktop.swingx.JXFrame;

import javax.swing.*;
import java.lang.reflect.InvocationTargetException;

/**
 * User: nazmul
 * Date: Sep 24, 2007
 * Time: 11:25:54 AM
 */
public class SwingMain {

    public static void main(String[] args) {
        final String[] _args_ = args;

        try {
            SwingUtilities.invokeAndWait(new Runnable() {
                public void run() {
                    launchInEDT(_args_);
                }
            });
        } catch (InterruptedException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }
    }

    public static void launchInEDT(String[] args) {
        JXFrame frame = new JXFrame();
        frame.setDefaultCloseOperation(JXFrame.EXIT_ON_CLOSE);
        frame.add(new SamplePanel().getBorderPanel());
        frame.pack();
        frame.setLocationByPlatform(true);
        frame.setVisible(true);
    }


}
