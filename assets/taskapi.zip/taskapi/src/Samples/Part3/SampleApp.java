/*
 * Created by JFormDesigner on Thu Mar 27 12:38:02 EDT 2008
 */

package Samples.Part3;

import Samples.SharedComponents.*;
import Task.*;
import Task.Manager.*;
import Task.ProgressMonitor.*;
import Task.Support.CoreSupport.*;
import Task.Support.GUISupport.*;
import com.jgoodies.forms.factories.*;
import info.clearthought.layout.*;
import org.apache.commons.httpclient.methods.*;

import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.awt.event.*;
import java.beans.*;
import java.util.concurrent.*;

/** @author nazmul idris */
public class SampleApp extends JFrame {
//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
// data members
//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
/** reference to task */
private SimpleTask _task;

//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
// main method...
//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

public static void main(String[] args) {
  Utils.createInEDT(SampleApp.class);
}

//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
// constructor
//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

private void doInit() {
  GUIUtils.setAppIcon(this, "burn.png");
  GUIUtils.centerOnScreen(this);
  setVisible(true);

  int W = 28, H = W;
  boolean blur = false;
  float alpha = .7f;

  try {
    btnStartTask.setIcon(ImageUtils.loadScaledBufferedIcon("ok1.png", W, H, blur, alpha));
    btnCancelTask.setIcon(ImageUtils.loadScaledBufferedIcon("alert-stop.png", W, H, blur, alpha));
    btnCancelUIHook.setIcon(ImageUtils.loadScaledBufferedIcon("alert-stop.png", W, H, blur, alpha));
    btnShutdownTask.setIcon(ImageUtils.loadScaledBufferedIcon("exit.png", W, H, blur, alpha));
    btnClearStatus.setIcon(ImageUtils.loadScaledBufferedIcon("bulb.png", W, H, blur, alpha));
    btnQuit.setIcon(ImageUtils.loadScaledBufferedIcon("charging.png", W, H, blur, alpha));
  }
  catch (Exception e) {
    System.out.println(e);
  }

  _setupTask();
}

/** create a test task and wire it up with a task handler that dumps output to the textarea */
@SuppressWarnings("unchecked")
private void _setupTask() {

  TaskExecutorIF<ByteBuffer> functor = new TaskExecutorAdapter<ByteBuffer>() {
    public ByteBuffer doInBackground(Future<ByteBuffer> swingWorker, SwingUIHookAdapter hook) throws Exception {

      try {

        _initHook(hook);

        PostMethod post = HttpUtils.sendMonitoredPOSTRequest(
            ttfURI.getText(),
            hook,
            new ByteBuffer(ttaInput.getText().getBytes()),
            "text/xml"
        );

        ByteBuffer data = HttpUtils.getMonitoredResponse(hook, post);

        return data;

      }
      catch (Exception e){
        e.printStackTrace();
        throw e;
      }

    }

    @Override public String getName() {
      return _task.getName();
    }
  };

  _task = new SimpleTask(new TaskManager(),
                         functor,
                         "HTTP POST task",
                         "NetworkTask that performs HTTP POST",
                         AutoShutdownSignals.Daemon);

  _task.addStatusListener(new PropertyChangeListener() {
    public void propertyChange(PropertyChangeEvent evt) {
      sout(":: task status change - " + ProgressMonitorUtils.parseStatusMessageFrom(evt));
      lblProgressStatus.setText(ProgressMonitorUtils.parseStatusMessageFrom(evt));
    }
  });

  _task.setTaskHandler(new
      SimpleTaskHandler<ByteBuffer>() {
        @Override public void beforeStart(AbstractTask task) {
          sout(":: taskHandler - beforeStart");
        }
        @Override public void started(AbstractTask task) {
          sout(":: taskHandler - started ");
        }
        /** {@link SampleApp#_initHook} adds the task status listener, which is removed here */
        @Override public void stopped(long time, AbstractTask task) {
          sout(":: taskHandler [" + task.getName() + "]- stopped");
          sout(":: time = " + time / 1000f + "sec");
          task.getUIHook().clearAllStatusListeners();
        }
        @Override public void interrupted(Throwable e, AbstractTask task) {
          sout(":: taskHandler [" + task.getName() + "]- interrupted - " + e.toString());
        }
        @Override public void ok(ByteBuffer value, long time, AbstractTask task) {
          sout(":: taskHandler [" + task.getName() + "]- ok - size=" + (value == null
                                                                        ? "null"
                                                                        : value.toString()));
          _displayDataInFrame(value);

        }
        @Override public void error(Throwable e, long time, AbstractTask task) {
          sout(":: taskHandler [" + task.getName() + "]- error - " + e.toString());
        }
        @Override public void cancelled(long time, AbstractTask task) {
          sout(" :: taskHandler [" + task.getName() + "]- cancelled");
        }
      }
  );
}

private SwingUIHookAdapter _initHook(SwingUIHookAdapter hook) {
  hook.enableRecieveStatusNotification(checkboxRecvStatus.isSelected());
  hook.enableSendStatusNotification(checkboxSendStatus.isSelected());

  hook.setProgressMessage(ttfProgressMsg.getText());

  PropertyChangeListener listener = new PropertyChangeListener() {
    public void propertyChange(PropertyChangeEvent evt) {
      SwingUIHookAdapter.PropertyList type = ProgressMonitorUtils.parseTypeFrom(evt);
      int progress = ProgressMonitorUtils.parsePercentFrom(evt);
      String msg = ProgressMonitorUtils.parseMessageFrom(evt);

      progressBar.setValue(progress);
      progressBar.setString(type.toString());

      sout(msg);
    }
  };

  hook.addRecieveStatusListener(listener);
  hook.addSendStatusListener(listener);
  hook.addUnderlyingIOStreamInterruptedOrClosed(new PropertyChangeListener() {
    public void propertyChange(PropertyChangeEvent evt) {
      sout(evt.getPropertyName() + " fired!!!");
    }
  });

  return hook;
}

private void _displayDataInFrame(ByteBuffer data) {

  final JFrame frame = new JFrame("Response from HTTP POST");
  GUIUtils.setAppIcon(frame, "71.png");
  frame.setDefaultCloseOperation(DISPOSE_ON_CLOSE);

  JTextArea tta = new JTextArea(new String(data.getBytes()));
  tta.setRows(10);
  tta.setColumns(80);

  tta.addMouseListener(new MouseAdapter() {
    @Override public void mouseClicked(MouseEvent e) {
      frame.dispose();
    }
  });

  frame.setContentPane(new JScrollPane(tta));
  frame.pack();

  GUIUtils.centerOnScreen(frame);
  frame.setVisible(true);
}

/** simply dump status info to the textarea */
private void sout(final String s) {
  Runnable soutRunner = new Runnable() {
    public void run() {
      if (ttaStatus.getText().equals("")) {
        ttaStatus.setText(s);
      }
      else {
        ttaStatus.setText(ttaStatus.getText() + "\n" + s);
      }
    }
  };

  if (ThreadUtils.isInEDT()) {
    soutRunner.run();
  }
  else {
    SwingUtilities.invokeLater(soutRunner);
  }
}

private void startTaskAction() {
  try {
    _task.execute();
  }
  catch (TaskException e) {
    sout(e.getMessage());
  }
}

private void cancelTaskAction() {
  _task.cancel();
}

private void canceUIHookAction() {
  _task.getUIHook().cancel();
}

private void shutdownTaskAction() {
  _task.shutdown();
}

private void quitProgram() {
  _task.shutdown();
  System.exit(0);
}

private void clearSystemOut() {
  ttaStatus.setText(null);
}

//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
// JFormDesigner generated stuff...
//XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

public SampleApp() {
  initComponents();
  doInit();
}

private void initComponents() {
  // JFormDesigner - Component initialization - DO NOT MODIFY  //GEN-BEGIN:initComponents
  // Generated using JFormDesigner non-commercial license
  dialogPane = new GradientPanel();
  contentPanel = new JPanel();
  panel1 = new JPanel();
  btnStartTask = new JButton();
  btnShutdownTask = new JButton();
  btnClearStatus = new JButton();
  btnCancelTask = new JButton();
  btnCancelUIHook = new JButton();
  btnQuit = new JButton();
  label1 = new JLabel();
  ttfURI = new JTextField();
  scrollPane2 = new JScrollPane();
  ttaInput = new JTextArea();
  scrollPane1 = new JScrollPane();
  ttaStatus = new JTextArea();
  panel2 = new JPanel();
  panel3 = new JPanel();
  checkboxRecvStatus = new JCheckBox();
  checkboxSendStatus = new JCheckBox();
  ttfProgressMsg = new JTextField();
  progressBar = new JProgressBar();
  lblProgressStatus = new JLabel();

  //======== this ========
  setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
  setTitle("Part 3 - Sample Application using Task API. Using SimpleTask and HTTP POST.");
  setIconImage(null);
  Container contentPane = getContentPane();
  contentPane.setLayout(new BorderLayout());

  //======== dialogPane ========
  {
  	dialogPane.setBorder(new EmptyBorder(12, 12, 12, 12));
  	dialogPane.setOpaque(false);
  	dialogPane.setLayout(new BorderLayout());

  	//======== contentPanel ========
  	{
  		contentPanel.setOpaque(false);
  		contentPanel.setLayout(new TableLayout(new double[][] {
  			{TableLayout.FILL},
  			{TableLayout.PREFERRED, TableLayout.PREFERRED, TableLayout.PREFERRED, TableLayout.FILL, TableLayout.PREFERRED}}));
  		((TableLayout)contentPanel.getLayout()).setHGap(5);
  		((TableLayout)contentPanel.getLayout()).setVGap(5);

  		//======== panel1 ========
  		{
  			panel1.setOpaque(false);
  			panel1.setBorder(new CompoundBorder(
  				new TitledBorder("Task Control - start, cancel, stop SimpleTask"),
  				Borders.DLU2_BORDER));
  			panel1.setLayout(new TableLayout(new double[][] {
  				{0.17, 0.17, 0.17, 0.17, 0.05, TableLayout.FILL},
  				{TableLayout.PREFERRED, TableLayout.PREFERRED, TableLayout.PREFERRED}}));
  			((TableLayout)panel1.getLayout()).setHGap(5);
  			((TableLayout)panel1.getLayout()).setVGap(5);

  			//---- btnStartTask ----
  			btnStartTask.setText("Start Task");
  			btnStartTask.setMnemonic('S');
  			btnStartTask.addActionListener(new ActionListener() {
  				public void actionPerformed(ActionEvent e) {
  					startTaskAction();
  				}
  			});
  			panel1.add(btnStartTask, new TableLayoutConstraints(0, 0, 1, 0, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));

  			//---- btnShutdownTask ----
  			btnShutdownTask.setText("Shutdown Task");
  			btnShutdownTask.setMnemonic('T');
  			btnShutdownTask.addActionListener(new ActionListener() {
  				public void actionPerformed(ActionEvent e) {
  					shutdownTaskAction();
  				}
  			});
  			panel1.add(btnShutdownTask, new TableLayoutConstraints(2, 0, 3, 0, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));

  			//---- btnClearStatus ----
  			btnClearStatus.setText("Clear status");
  			btnClearStatus.setMnemonic('L');
  			btnClearStatus.setHorizontalTextPosition(SwingConstants.RIGHT);
  			btnClearStatus.setHorizontalAlignment(SwingConstants.LEFT);
  			btnClearStatus.addActionListener(new ActionListener() {
  				public void actionPerformed(ActionEvent e) {
  					clearSystemOut();
  				}
  			});
  			panel1.add(btnClearStatus, new TableLayoutConstraints(5, 0, 5, 0, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));

  			//---- btnCancelTask ----
  			btnCancelTask.setText("Cancel Task");
  			btnCancelTask.setMnemonic('C');
  			btnCancelTask.addActionListener(new ActionListener() {
  				public void actionPerformed(ActionEvent e) {
  					cancelTaskAction();
  				}
  			});
  			panel1.add(btnCancelTask, new TableLayoutConstraints(0, 1, 1, 1, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));

  			//---- btnCancelUIHook ----
  			btnCancelUIHook.setText("Cancel UIHook");
  			btnCancelUIHook.setMnemonic('U');
  			btnCancelUIHook.addActionListener(new ActionListener() {
  				public void actionPerformed(ActionEvent e) {
  					canceUIHookAction();
  				}
  			});
  			panel1.add(btnCancelUIHook, new TableLayoutConstraints(2, 1, 3, 1, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));

  			//---- btnQuit ----
  			btnQuit.setText("Quit");
  			btnQuit.setMnemonic('Q');
  			btnQuit.setHorizontalAlignment(SwingConstants.LEFT);
  			btnQuit.setHorizontalTextPosition(SwingConstants.RIGHT);
  			btnQuit.addActionListener(new ActionListener() {
  				public void actionPerformed(ActionEvent e) {
  					quitProgram();
  				}
  			});
  			panel1.add(btnQuit, new TableLayoutConstraints(5, 1, 5, 1, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));

  			//---- label1 ----
  			label1.setText("URI for POST");
  			panel1.add(label1, new TableLayoutConstraints(0, 2, 0, 2, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));

  			//---- ttfURI ----
  			ttfURI.setBorder(Borders.createEmptyBorder("1dlu, 1dlu, 1dlu, 1dlu"));
  			ttfURI.setText("http://blogsearch.google.com/ping/RPC2");
  			ttfURI.setToolTipText("Enter your own URI for a file to download in the background");
  			panel1.add(ttfURI, new TableLayoutConstraints(1, 2, 5, 2, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));
  		}
  		contentPanel.add(panel1, new TableLayoutConstraints(0, 0, 0, 0, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));

  		//======== scrollPane2 ========
  		{
  			scrollPane2.setBorder(new TitledBorder("Data to send to the XML RPC service"));
  			scrollPane2.setOpaque(false);

  			//---- ttaInput ----
  			ttaInput.setBorder(Borders.createEmptyBorder("1dlu, 1dlu, 1dlu, 1dlu"));
  			ttaInput.setToolTipText("<html>Task progress updates (messages) are displayed here,<br>along with any other output generated by the Task.<html>");
  			ttaInput.setRows(6);
  			ttaInput.setText("<?xml version=\"1.0\"?>\n<methodCall>\n  <methodName>weblogUpdates.extendedPing</methodName>\n  <params>\n    <param>\n      <value>Official Google Blog</value>\n    </param>\n    <param>\n      <value>http://googleblog.blogspot.com/</value>\n    </param>\n    <param>\n      <value>http://googleblog.blogspot.com/</value>\n    </param>\n    <param>\n      <value>http://googleblog.blogspot.com/atom.xml</value>\n    </param>\n    <param>\n      <value>\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n      tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|tag3tag1|tag2|\n    </param>\n  </params>\n</methodCall>");
  			scrollPane2.setViewportView(ttaInput);
  		}
  		contentPanel.add(scrollPane2, new TableLayoutConstraints(0, 1, 0, 1, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));

  		//======== scrollPane1 ========
  		{
  			scrollPane1.setBorder(new TitledBorder("System.out - displays all status and progress messages, etc."));
  			scrollPane1.setOpaque(false);

  			//---- ttaStatus ----
  			ttaStatus.setBorder(Borders.createEmptyBorder("1dlu, 1dlu, 1dlu, 1dlu"));
  			ttaStatus.setToolTipText("<html>Task progress updates (messages) are displayed here,<br>along with any other output generated by the Task.<html>");
  			ttaStatus.setRows(9);
  			scrollPane1.setViewportView(ttaStatus);
  		}
  		contentPanel.add(scrollPane1, new TableLayoutConstraints(0, 2, 0, 2, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));

  		//======== panel2 ========
  		{
  			panel2.setOpaque(false);
  			panel2.setBorder(new CompoundBorder(
  				new TitledBorder("Status - control progress reporting"),
  				Borders.DLU2_BORDER));
  			panel2.setLayout(new TableLayout(new double[][] {
  				{0.45, TableLayout.FILL, 0.45},
  				{TableLayout.PREFERRED, TableLayout.PREFERRED}}));
  			((TableLayout)panel2.getLayout()).setHGap(5);
  			((TableLayout)panel2.getLayout()).setVGap(5);

  			//======== panel3 ========
  			{
  				panel3.setOpaque(false);
  				panel3.setLayout(new GridLayout(1, 2));

  				//---- checkboxRecvStatus ----
  				checkboxRecvStatus.setText("Enable \"Recieve\"");
  				checkboxRecvStatus.setOpaque(false);
  				checkboxRecvStatus.setToolTipText("Task will fire \"send\" status updates");
  				panel3.add(checkboxRecvStatus);

  				//---- checkboxSendStatus ----
  				checkboxSendStatus.setText("Enable \"Send\"");
  				checkboxSendStatus.setOpaque(false);
  				checkboxSendStatus.setToolTipText("Task will fire \"recieve\" status updates");
  				checkboxSendStatus.setSelected(true);
  				panel3.add(checkboxSendStatus);
  			}
  			panel2.add(panel3, new TableLayoutConstraints(0, 0, 0, 0, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));

  			//---- ttfProgressMsg ----
  			ttfProgressMsg.setText("Posting data to XML RPC service");
  			ttfProgressMsg.setToolTipText("Set the task progress message here");
  			panel2.add(ttfProgressMsg, new TableLayoutConstraints(2, 0, 2, 0, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));

  			//---- progressBar ----
  			progressBar.setStringPainted(true);
  			progressBar.setString("progress %");
  			progressBar.setToolTipText("% progress is displayed here");
  			panel2.add(progressBar, new TableLayoutConstraints(0, 1, 0, 1, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));

  			//---- lblProgressStatus ----
  			lblProgressStatus.setText("task status listener");
  			lblProgressStatus.setHorizontalTextPosition(SwingConstants.LEFT);
  			lblProgressStatus.setHorizontalAlignment(SwingConstants.LEFT);
  			lblProgressStatus.setToolTipText("Task status messages are displayed here when the task runs");
  			panel2.add(lblProgressStatus, new TableLayoutConstraints(2, 1, 2, 1, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));
  		}
  		contentPanel.add(panel2, new TableLayoutConstraints(0, 4, 0, 4, TableLayoutConstraints.FULL, TableLayoutConstraints.FULL));
  	}
  	dialogPane.add(contentPanel, BorderLayout.CENTER);
  }
  contentPane.add(dialogPane, BorderLayout.CENTER);
  setSize(675, 610);
  setLocationRelativeTo(null);
  // JFormDesigner - End of component initialization  //GEN-END:initComponents
}

// JFormDesigner - Variables declaration - DO NOT MODIFY  //GEN-BEGIN:variables
// Generated using JFormDesigner non-commercial license
private GradientPanel dialogPane;
private JPanel contentPanel;
private JPanel panel1;
private JButton btnStartTask;
private JButton btnShutdownTask;
private JButton btnClearStatus;
private JButton btnCancelTask;
private JButton btnCancelUIHook;
private JButton btnQuit;
private JLabel label1;
private JTextField ttfURI;
private JScrollPane scrollPane2;
private JTextArea ttaInput;
private JScrollPane scrollPane1;
private JTextArea ttaStatus;
private JPanel panel2;
private JPanel panel3;
private JCheckBox checkboxRecvStatus;
private JCheckBox checkboxSendStatus;
private JTextField ttfProgressMsg;
private JProgressBar progressBar;
private JLabel lblProgressStatus;
// JFormDesigner - End of variables declaration  //GEN-END:variables
}