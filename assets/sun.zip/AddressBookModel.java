/********************************************************************
 * Copyright (c) 1998-99 The Bean Factory, LLC. 
 * All Rights Reserved.
 *
 * The Bean Factory, LLC. makes no representations or 
 * warranties about the suitability of the software, either express
 * or implied, including but not limited to the implied warranties of 
 * merchantableness, fitness for a particular purpose, or 
 * non-infringement. The Bean Factory, LLC. shall not be 
 * liable for any damages suffered by licensee as a result of using,
 * modifying or distributing this software or its derivatives.
 *
 *******************************************************************/


import com.sun.xml.tree.*;
import org.w3c.dom.*;

import java.awt.*;
import javax.swing.*;
import javax.swing.event.*;
import javax.swing.table.*;
import java.util.*;
import java.io.*;
import java.net.*;

/********************************************************************
 <B>AddressBookModel</B> implements TableModel.  This model creates
 a DOM object from an XML document and gets information from the
 DOM object.
 
 Here is the DTD for the XML document that holds the actual information:
    <?xml version="1.0"?>
    <!DOCTYPE ADDRESSBOOK [
    <!ELEMENT ADDRESSBOOK (PERSON)*>
    <!ELEMENT PERSON (LASTNAME, FIRSTNAME, COMPANY, EMAIL)>
    <!ELEMENT LASTNAME (#PCDATA)>
    <!ELEMENT FIRSTNAME (#PCDATA)>
    <!ELEMENT COMPANY (#PCDATA)>
    <!ELEMENT EMAIL (#PCDATA)>
    ]>


 @version      : 1.0
 @author       : Nazmul Idris

 @see   XmlUtils
********************************************************************/

public class AddressBookModel implements TableModel{

//CONSTANTS
public static final String URL = 
    "http://beanfactory.com/xml/AddressBook.xml";

//TABLE META DATA
public static final String ROOT_ELEMENT_TAG = "PERSON";

public static final String[] colNames ={
    "LASTNAME",
    "FIRSTNAME",
    "COMPANY",
    "EMAIL"
};

public static final Class[] colClasses ={
    String.class,
    String.class,
    String.class,
    String.class
};

public static final int 
    LASTNAME_COL    = 0,
    FIRSTNAME_COL   = 1,
    COMPANY_COL     = 2,
    EMAIL_COL       = 3;

//DATA
//DOM object to hold XML document contents
protected Document doc;     
//used to hold a list of TableModelListeners
protected java.util.List tableModelListeners = 
    new ArrayList();        

/**
 main method
 */
public static void main(String []args){
    new AddressBookModel();
}//end main

/**
 Constructor - create a DOM
 */
public AddressBookModel(){
    try {
        //create xml document
        doc = XmlDocumentBuilder.createXmlDocument(URL);
    }
    catch( Exception e ){
        System.out.println( e );
    }
}


//
// TableModel implementation
//

/**
 Return the number of columns for the model.

 @return    the number of columns in the model
*/
public int getColumnCount() {
    return colClasses.length;
}
/**
 Return the number of persons in an XML document
 
 @return    the number or rows in the model
*/
public int getRowCount() {
    return XmlUtils.getSize( doc , ROOT_ELEMENT_TAG );
}

/**
 Return an XML data given its location
 
 @param	    r   the row whose value is to be looked up
 @param	    c 	the column whose value is to be looked up
 @return	the value Object at the specified cell
*/
public Object getValueAt(int r, int c) {

    //must get row first
    Element row = XmlUtils.getElement( doc , ROOT_ELEMENT_TAG , r );

    //must get value for column in this row
    return XmlUtils.getValue( row , colNames[c] );

}

/**
 Return the name of column for the table.
 
 @param	    c   the index of column
 @return    the name of the column
*/
public String getColumnName(int c) {
    return colNames[ c ];
}
/**
 Return column class
 
 @parm      c the index of column
 @return    the common ancestor class of the object values in the model.
*/
public Class getColumnClass(int c) {
    return colClasses[ c ];
}

/**
 Return false - table is not editable
 
 @param	    r	the row whose value is to be looked up
 @param	    c	the column whose value is to be looked up
 @return	true if the cell is editable.
*/
public boolean isCellEditable(int r, int c) {
    return false;
}

/**
 This method is not implemented, because the table is not editable.
 
 @param	    value		 the new value
 @param	    r	 the row whose value is to be changed
 @param	    c 	 the column whose value is to be changed
*/
public void setValueAt(Object value, int r, int c) {
}

/**
 Add a listener to the list that's notified each time a change
 to the data model occurs.

 @param	l		the TableModelListener
*/
public void addTableModelListener(TableModelListener l) {
    //add a listener only if the listener is not already registered
    if( !tableModelListeners.contains(l)) {
        tableModelListeners.add(l);
    }
}
/**
 Remove a listener from the list that's notified each time a
 change to the data model occurs.

 @param	l		the TableModelListener
*/
public void removeTableModelListener(TableModelListener l) {
    //remove a listener only if the listener is already registered
    if( tableModelListeners.contains(l)) {
        tableModelListeners.remove(l);
    }
}

}//end class
