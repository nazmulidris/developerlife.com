package SampleService;

import Task.Support.CoreSupport.*;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

/**
 * DataPingServlet allows you to test your HTTP POST/GET operations. Whatever data you send it, is sent back, so you
 * can see progress monitors working in reporting Send/Recieve updates.
 *
 * @author Nazmul Idris
 * @version 1.0
 * @since Mar 28, 2008, 7:06:21 PM
 */
public class DataPingServlet extends HttpServlet {

@Override protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException
{
  doPost(request, response);
}

@Override protected void doPost(HttpServletRequest request, HttpServletResponse res)
    throws ServletException, IOException
{
  ByteBuffer bb = new ByteBuffer(request.getInputStream());

  res.setContentType("application/octet-stream");
  res.setContentLength(bb.getSize());

  ServletOutputStream sos = res.getOutputStream();
  sos.write(bb.getBytes());
  sos.flush();
  sos.close();
}

}//end class DataPingServlet
